<?php

echo "5" + "10";
